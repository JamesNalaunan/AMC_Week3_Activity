import React from 'react';
import {StyleSheet, TextInput} from 'react-native';
import {SafeAreaView, SafeAreaProvider} from 'react-native-safe-area-context';


const TextInputExample = () => {
  const [textname, onChangeTextname] = React.useState('Name :');
  const [school, onChangeTextschool] = React.useState('School :');
  const [address, onChangeaddress] = React.useState('Address :');
  const [course, onChangecourse] = React.useState('Course :');
  const [email, onChangeemail] = React.useState('Email :');
  const [age, onChangeNumberage] = React.useState('Age :');
  const [contact, onChangecontact] = React.useState('Contact no.');
  const [value, onChangeText] = React.useState('About Me :');

  return (
    <SafeAreaProvider>
      <SafeAreaView>
        <TextInput
          style={styles.input}
          onChangeText={onChangeTextname}
          value={textname}
        />
        <TextInput
          style={styles.input}
          onChangeText={onChangeNumberage}
          value={age}
          placeholder="Age :"
          keyboardType="numeric"
        />
          <TextInput
          style={styles.input}
          onChangeText={onChangeaddress}
          value={address}
          placeholder="Address :"
          keyboardType="text"
        />
          <TextInput
          style={styles.input}
          onChangeText={onChangeTextschool}
          value={school}
          placeholder="School :"
          keyboardType="text"
        />
          <TextInput
          style={styles.input}
          onChangeText={onChangecourse}
          value={course}
          placeholder="Course :"
          keyboardType="text"
        />
          <TextInput
          style={styles.input}
          onChangeText={onChangeemail}
          value={email}
          placeholder="Email :"
          keyboardType="text"
        />
          <TextInput
          style={styles.input}
          onChangeText={onChangecontact}
          value={contact}
          placeholder="Contact no. :"
          keyboardType="numeric"
        />
        <TextInput
          editable
          multiline
          numberOfLines={4}
          maxLength={40}
          onChangeText={text => onChangeText(text)}
          value={value}
          style={styles.textInput1}
        />
      </SafeAreaView>
    </SafeAreaProvider>
  );
};

const styles = StyleSheet.create({
  input: {
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 10,
  },
  textInput1: {
    borderBottomColor: '#000',
    borderBottomWidth: 1,
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    padding: 10,
  }
});

export default TextInputExample;